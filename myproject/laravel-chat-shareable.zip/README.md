﻿# Laravel Chat Application - Shareable Package

## Quick Start

1. Extract this package
2. Open terminal in the extracted folder
3. Run: .\docker-start.ps1

Or manually:

`powershell
docker-compose up -d --build
docker-compose exec app composer install
docker-compose exec app php artisan key:generate
docker-compose exec app php artisan migrate
`",
    ",
    

- Make sure Docker Desktop is running
- Create a .env file with database settings:
  - DB_HOST=db
  - DB_DATABASE=laravel
  - DB_USERNAME=laravel
  - DB_PASSWORD=root

## Access

- Web: http://localhost:8000
- API: http://localhost:8000/api
